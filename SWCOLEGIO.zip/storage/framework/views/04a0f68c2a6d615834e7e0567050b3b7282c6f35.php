<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-md-6">
        <a href="<?php echo e(url('curso/create')); ?>" class="btn btn-primary">Registrar curso</a>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Apoderados</strong>
            </div>
            <div class="card-body">
                <table class="table table-responsive-sm table-hover table-sm" id="dataTable">
                    <thead>
                        <tr>
                            <th>Asignatura</th>
                            <th>Grado</th>
                            <th>Docente</th>
                            <th>N° Alumnos</th>
                            <th>Año</th>
                            <th>Estado</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cur->asig_nom); ?></td>
                            <td>
                                <?php if($cur->curs_grado <= 6): ?>
                                    <?php echo e($cur->curs_grado . '° de primaria'); ?>

                                <?php elseif($cur->curs_grado == 7): ?>
                                    <?php echo e('1° de secundaria'); ?>

                                <?php elseif($cur->curs_grado == 8): ?>
                                    <?php echo e('2° de secundaria'); ?>          
                                <?php elseif($cur->curs_grado == 9): ?>
                                    <?php echo e('3° de secundaria'); ?>  
                                <?php elseif($cur->curs_grado == 10): ?>
                                    <?php echo e('4° de secundaria'); ?>  
                                <?php elseif($cur->curs_grado == 11): ?>
                                    <?php echo e('5° de secundaria'); ?>  
                                <?php else: ?>
                                    <?php echo e('Egresado'); ?>  
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($cur->trab_ape . ', '. $cur->trab_nom); ?></td>
                            <td class="text-center">
                                <?php $nalum = DB::table('alumno_curso')->where('curso_id','=',$cur->curs_id)->count(); ?>
                                <?php echo e($nalum); ?>

                            </td>
                            <td><?php echo e($cur->curs_año); ?></td>
                            <td>
                              <?php if($cur->curs_est == 1): ?>
                                <span class="badge badge-success">Activo</span>
                              <?php else: ?>
                              <span class="badge badge-danger">Inactivo</span>
                              <?php endif; ?>
                            </td>
                            <td>   
                                <a data-toggle="modal" data-target="#modal-info-<?php echo e($cur->curs_id); ?>"  class="btn btn-sm btn-info"><i class="fa fa-search"></i></a>  
                                <?php echo $__env->make('curso.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <a href="<?php echo e(url('curso/'.$cur->curs_id.'/edit')); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a> 
                                <a class="btn btn-sm btn-secondary" title="Matricular alumnos" href="<?php echo e(url('matricula/'.$cur->curs_id)); ?>"><i class="fa fa-group"></i></a>      
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JUANA ALARCO DE DAMMERT\new swcolegio\SWCOLEGIO\resources\views/curso/index.blade.php ENDPATH**/ ?>