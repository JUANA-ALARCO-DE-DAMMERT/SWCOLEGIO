<p align="center"><strong>Reporte: Última Conexión</strong></p> <br>
<div >
	<table align="center" border="1">
		<thead>
			<tr>
				<th>DNI</th>
				<th>Alumno</th>
				<th>Última conexión</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($a->alum_dni); ?></td>
				<td><?php echo e($a->alum_ape . ', ' . $a->alum_nom); ?></td>
				<td><?php echo e($a->last_login); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</div><?php /**PATH C:\xampp\htdocs\JUANA ALARCO DE DAMMERT\new swcolegio\SWCOLEGIO\resources\views/pdf/lastconection.blade.php ENDPATH**/ ?>