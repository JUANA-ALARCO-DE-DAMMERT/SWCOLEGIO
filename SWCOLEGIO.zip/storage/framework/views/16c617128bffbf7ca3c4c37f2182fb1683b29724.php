<?php $__env->startSection('contenido'); ?>
<?php 
    $fechas = DB::table('asistencia')
                    ->select('asistencia.asis_fecha')
                    ->where('asistencia.asis_idcurso','=',$idcurso)
                    ->distinct()
                    ->get();
    $alumnos = DB::table('alumno_curso')
                ->join('alumno','alumno.alum_id','alumno_curso.alumno_id')
                ->where('alumno_curso.curso_id','=',$idcurso)
                ->orderby('alumno.alum_ape','asc')
                ->get();
?>
<div class="row mt-4">
    <div class="col-md-6">
        <a href="<?php echo e(url('asistencia/registrar/'.$idcurso)); ?>" id="btn-only1click" class="btn btn-primary">Registrar asistencia</a>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card my-3">
            <div class="card-header">
                <div class="card-header-actions">
                    <a href="<?php echo e(url('curso/'.$idcurso)); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-responsive" id="">
                    <thead>
                        <tr>
                            <th>Alumnos</th>
                            <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><small><?php echo e(date("d/m/Y", strtotime($f->asis_fecha))); ?></small></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </tr>
                    </thead>
                    <tbody>
                            <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($a->alum_ape.', '.$a->alum_nom); ?></td>
                                <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                    $data = DB::table('asistencia')
                                                    ->where([['asistencia.asis_fecha','=',$f->asis_fecha],
                                                            ['asistencia.asis_idcurso','=',$idcurso],
                                                            ['asistencia.asis_idalumno','=',$a->alum_id]])
                                                    ->first();
                                ?>
                                    <td>
                                        <?php if($data->asis_est == 0): ?>
                                            A
                                        <?php elseif($data->asis_est == 1): ?>
                                            T
                                        <?php else: ?>
                                            F
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    // Variable global que nos dirá si hemos dado un click al botón
var clicando= false;

// Evento de click del primer botón
$("#btn-dobleclick").click(function() {
  // Mostramos el Alert
  alert( "Handler for dobleclick.click() called." );
});

// Evento del segundo boton
$("#btn-only1click").click(function() {
  // Si ha sido clicado
  if (clicando){
    // Mostramos que ya se ha clicado, y no puede clicarse de nuevo
    alert( "Que ya he realizado un click." );
  // Si no ha sido clicado
  } else {
    // Le decimos que ha sido clicado
    clicando= true;
    // Mostramos el mensaje de que ha sido clicado
    alert( "Bienvenido al registro de Asistencias " );
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SWCOLEGIO\resources\views/asistencia/show.blade.php ENDPATH**/ ?>