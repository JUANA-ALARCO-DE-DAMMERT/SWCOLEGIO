<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <title>Apoderados</title>
      <meta name="viewport" content="">
      <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
	<div class="header-wrapper">
      <div >
        <img src="<?php echo e(asset('img/logo-jad.jpeg')); ?>" width="60" height="60">
      </div>
    </div>
    <div>
    	<H1 class="m-0 font-weight-bold text-primary"><center>APODERADOS</center></H1>
    </div>
    <table class="table table-hover table-bordered table-sm" id="dataTable" width="80%" cellspacing="0"  >
                  <thead>
                        <tr>
                        		<th>DNI</th>
								<th>Apoderado</th>
								<th>E-mail</th>
								<th>Teléfono</th>	
                        </tr>
                  </thead>
                  <tbody>
                  	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td class="text-sm-left"><?php echo e($a->apod_dni); ?></td>
								<td class="text-sm-left"><?php echo e($a->apod_ape . ', ' . $a->apod_nom); ?></td>
								<td class="text-sm-left"><?php echo e($a->apod_email); ?></td>
								<td class="text-sm-left"><?php echo e($a->apod_tel); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
            </table>
</body>
</html>


<!-- <p align="center"><strong>APODERADOS</strong></p> <br>
<table border="1">
		<thead>
			<tr>
				<th>DNI</th>
				<th>Apoderado</th>
				<th>E-mail</th>
				<th>Teléfono</th>			
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-sm-left"><?php echo e($a->apod_dni); ?></td>
				<td class="text-sm-left"><?php echo e($a->apod_ape . ', ' . $a->apod_nom); ?></td>
				<td class="text-sm-left"><?php echo e($a->apod_email); ?></td>
				<td class="text-sm-left"><?php echo e($a->apod_tel); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table> --><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/pdf/apoderados.blade.php ENDPATH**/ ?>