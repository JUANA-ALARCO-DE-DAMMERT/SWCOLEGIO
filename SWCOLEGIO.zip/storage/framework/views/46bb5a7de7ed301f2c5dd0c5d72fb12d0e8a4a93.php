<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-md-6"></div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card my-3">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> Código del curso: <?php echo e($idcurso); ?>

            </div>
            <div class="card-body">
                <?php if(Auth::user()->hasRole('docen')): ?>
                    <a href="<?php echo e(url('reportes/'.$idcurso.'/lastconection')); ?>" id="btn-only1click" class="btn btn-danger"><i class="fa fa-print"></i> Última Conexión de Alumnos</a><br><br>
                    <a href="<?php echo e(url('reportes/'.$idcurso.'/asistenciadocen')); ?>" id="btn-only1click" class="btn btn-danger"><i class="fa fa-print"></i> Asistencias de los alumnos</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    // Variable global que nos dirá si hemos dado un click al botón
var clicando= false;

// Evento de click del primer botón
$("#btn-dobleclick").click(function() {
  // Mostramos el Alert
  alert( "Handler for dobleclick.click() called." );
});

// Evento del segundo boton
$("#btn-only1click").click(function() {
  // Si ha sido clicado
  if (clicando){
    // Mostramos que ya se ha clicado, y no puede clicarse de nuevo
    alert( "Que ya he realizado un click." );
  // Si no ha sido clicado
  } else {
    // Le decimos que ha sido clicado
    clicando= true;
    // Mostramos el mensaje de que ha sido clicado
    alert( "Se esta descargando la Ultima Conexión de Alumnos en PDF, espere a que termine la descarga." );
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/reportes/index.blade.php ENDPATH**/ ?>