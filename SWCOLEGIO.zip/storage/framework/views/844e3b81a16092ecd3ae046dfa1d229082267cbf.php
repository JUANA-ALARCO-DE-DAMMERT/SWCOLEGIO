<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <title>Tasa de asistencia Diaria</title>
      <meta name="viewport" content="">
      <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
	<div class="header-wrapper">
      <div >
        <img src="<?php echo e(asset('img/logo-jad.jpeg')); ?>" width="60" height="60">
      </div>
    </div>
    <div>
    	<H1 class="m-0 font-weight-bold text-primary"><center>Tasa de Asistencia Diaria</center></H1>
    </div>
    <table class="table table-hover table-bordered table-sm" id="dataTable" width="80%" cellspacing="0"  >
                  <thead>
                        <tr>
                        		<th>DNI</th>
								<th>Alumno</th>
								<th>Estado</th>	
                        </tr>
                  </thead>
                  <tbody>
                  	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($q->alum_dni); ?></td>
								<td><?php echo e($q->alum_ape); ?></td>
								<td>
									<?php if($q->asis_est == 0): ?>
                                    A
	                                <?php elseif($q->asis_est == 1): ?>
	                                    T
	                                <?php else: ?>
	                                    F
	                                <?php endif; ?>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
            </table>
            <p>Tasa de Asistencia: <?php echo e($ind); ?>%</p> 
</body>
</html>


<!-- <table>
	<thead>
		<tr>
			<th>DNI</th>
			<th>Alumno</th>
			<th>Estado</th>
		</tr>
	</thead>
		<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($q->alum_dni); ?></td>
				<td><?php echo e($q->alum_ape); ?></td>
				<td><?php echo e($q->asis_est); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<p>Tasa de Asistencia: <?php echo e($ind); ?>%</p> -->
<?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/pdf/repasisdiaro.blade.php ENDPATH**/ ?>