<table>
	<thead>
		<tr>
			<th>DNI</th>
			<th>Alumno</th>
			<th>Estado</th>
		</tr>
	</thead>
		<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($q->alum_dni); ?></td>
				<td><?php echo e($q->alum_ape); ?></td>
				<td><?php echo e($q->asis_est); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<p>Tasa de Asistencia: <?php echo e($ind); ?>%</p>
<?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/pdf/repasisdiaro.blade.php ENDPATH**/ ?>