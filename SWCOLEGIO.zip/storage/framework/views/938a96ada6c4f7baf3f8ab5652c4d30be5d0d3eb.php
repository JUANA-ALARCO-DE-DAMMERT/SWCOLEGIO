<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Editar curso</strong>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('curso/'.$curso->curs_id)); ?>" method="POST" class="form-horizontal"> 
                <?php echo method_field('PATCH'); ?>
                <?php echo e(csrf_field()); ?>

                    <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <p>Corregir los siguientes campos:</p>
                        <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <div class="form-group row">
                        <label class="col-md-2 col-form-label">Asignatura</label>
                        <div class="col-md-3">
                            <select name="curs_idasig" class="form-control" id="select-asignatura" readonly required>
                                <option value="<?php echo e($curso->asig_id); ?>" ><?php echo e($curso->asig_nom); ?></option>
                            </select>
                        </div>
                        <label class="col-md-1 col-form-label">Docente</label>
                        <div class="col-md-4">
                            <select name="curs_iddocen" class="form-control" id="select-docente" required>
                            <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($curso->curs_iddocen == $doc->trab_id): ?>
                                <option value="<?php echo e($doc->trab_id); ?>" selected><?php echo e($doc->trab_ape . ', ' . $doc->trab_nom); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($doc->trab_id); ?>"><?php echo e($doc->trab_ape . ', ' . $doc->trab_nom); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-2 col-form-label">Grado</label>
                        <div class="col-md-2">
                            <select name="curs_grado" class="form-control" required readonly>
                                <option value="<?php echo e($curso->curs_grado); ?>" >
                                    <?php if($curso->curs_grado <= 6): ?>
                                        <?php echo e($curso->curs_grado . '° de primaria'); ?>

                                    <?php elseif($curso->curs_grado == 7): ?>
                                        <?php echo e('1° de secundaria'); ?>

                                    <?php elseif($curso->curs_grado == 8): ?>
                                        <?php echo e('2° de secundaria'); ?>          
                                    <?php elseif($curso->curs_grado == 9): ?>
                                        <?php echo e('3° de secundaria'); ?>  
                                    <?php elseif($curso->curs_grado == 10): ?>
                                        <?php echo e('4° de secundaria'); ?>  
                                    <?php elseif($curso->curs_grado == 11): ?>
                                        <?php echo e('5° de secundaria'); ?>  
                                    <?php else: ?>
                                        <?php echo e('Egresado'); ?>  
                                    <?php endif; ?>
                                </option>
                            </select>
                        </div>
                        <label class="col-md-2 col-form-label">Año</label>
                        <div class="col-md-2">
                            <select class="form-control"  name="curs_año" size="1" readonly>
                                <option value="<?php echo e($curso->curs_año); ?>"><?php echo e($curso->curs_año); ?></option>
                            </select>
                        </div>
                    </div> 

                    <div class="form-actions">
                        <input type="submit" value="Modificar" class="btn btn-warning">
                        <a href="<?php echo e(url('curso')); ?>" class="btn btn-danger">Cancelar</a>
                    </div> 
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/curso/edit.blade.php ENDPATH**/ ?>