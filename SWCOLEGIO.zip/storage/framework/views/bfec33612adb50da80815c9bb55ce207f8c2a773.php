<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-md-6">
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card my-3">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> Código del curso: <?php echo e($idcurso); ?> / Exámenes Virtuales
                <div class="card-header-actions">
                    <a href="<?php echo e(url('curso/'.$idcurso)); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-hover table-bordered table-sm">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Fecha</th>
                            <th>Autor</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($examen->exa_titulo); ?></td>
                            <td><?php echo e($examen->exa_fecha); ?></td>
                            <td><?php echo e($examen->trab_ape . ', ' . $examen->trab_nom); ?></td>
                            <td>
                                <a href="<?php echo e(url('examen/'.$examen->exa_id)); ?>" class="btn btn-secondary btn-sm"><i class="fa fa-file-text"></i></a>                 
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/examen/listar.blade.php ENDPATH**/ ?>