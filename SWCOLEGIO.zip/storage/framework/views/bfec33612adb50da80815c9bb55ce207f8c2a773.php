<?php $__env->startSection('contenido'); ?>
<?php  $q = DB::table('curso')
                ->join('asignatura','asignatura.asig_id','curso.curs_idasig')
                ->where('curso.curs_id','=',$idcurso)
                ->first(); ?>
<div class="row mt-4">
    <div class="col-md-6">
        <?php if(Auth::user()->hasRole('docen')): ?>
            <a href="<?php echo e(url('newexamen/'.$idcurso)); ?>" class="btn btn-primary">Subir Exámen en línea</a>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card my-3">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> Curso: <?php echo e($q->asig_nom); ?> / Exámenes Virtuales
                <div class="card-header-actions">
                    <a href="<?php echo e(url('curso/'.$idcurso)); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-hover table-bordered table-sm" id="dataTable">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Fecha</th>
                            <th>Autor</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($examen->exa_titulo); ?></td>
                            <td><?php echo e($examen->exa_fecha); ?></td>
                            <td><?php echo e($examen->trab_ape . ', ' . $examen->trab_nom); ?></td>
                            <td>
                                <a href="<?php echo e(url('examen/'.$examen->exa_id)); ?>" class="btn btn-secondary btn-sm"><i class="fa fa-file-text"></i></a>
                                <!-- <?php if(Auth::user()->hasrole('docen')): ?> -->
                                <a href="<?php echo e(url('examen/'.$examen->exa_id.'/edit')); ?>" title="Editar examen" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>
                                <a href="<?php echo e(url('')); ?>" title="Eliminar examen" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                                <!-- <?php endif; ?>   -->            
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/examen/listar.blade.php ENDPATH**/ ?>