<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-md-6">
        <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#uploadFile"><i class="fa fa-upload"></i> Subir recurso</button>
        <?php echo $__env->make('recursos.modal-upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card my-3">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> Código del curso: <?php echo e($idcurso); ?> / <?php echo e($nbim); ?>° Bimestre / Recursos
                <div class="card-header-actions">
                    <a href="<?php echo e(url($idcurso.'/recursos')); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-hover table-bordered table-sm">
                    <thead>
                        <tr>
                            <th>Archivo</th>
                            <th>Propietario</th>
                            <th>Fecha</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <form action="<?php echo e(url('download')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <td><?php echo e($file->rec_archivo); ?></td>
                                <td>
                                    <?php if($file->rec_rol == 3): ?>
                                        <?php 
                                            $doc = DB::table('trabajador')
                                                    ->where('trab_dni','=',$file->rec_dni)->first();
                                        ?>
                                        <?php echo e($doc->trab_ape . ', ' . $doc->trab_nom); ?> 
                                    <?php elseif($file->rec_rol == 4): ?>
                                        <?php 
                                            $alum = DB::table('alumno')
                                                    ->where('alum_dni','=',$file->rec_dni)->first();
                                        ?>
                                        <?php echo e($alum->alum_ape . ', ' . $alum->alum_nom); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($file->rec_fechahora); ?></td>
                                <input type="hidden" value="<?php echo e($file->rec_archivo); ?>" name="filename">
                                <input type="hidden" value="<?php echo e($idcurso); ?>" name="idcurso">
                                <td><button type="submit" class="btn btn-success btn-sm"><i class="fa fa-download"></i></button></td>
                            </form>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SWCOLEGIO\resources\views/recursos/showfiles.blade.php ENDPATH**/ ?>