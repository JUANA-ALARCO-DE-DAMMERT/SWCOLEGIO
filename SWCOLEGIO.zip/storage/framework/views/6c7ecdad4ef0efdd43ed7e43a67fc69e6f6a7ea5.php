Sr(a). <strong><?php echo e($name); ?></strong>
<p><?php echo e($body); ?></p><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/mail.blade.php ENDPATH**/ ?>