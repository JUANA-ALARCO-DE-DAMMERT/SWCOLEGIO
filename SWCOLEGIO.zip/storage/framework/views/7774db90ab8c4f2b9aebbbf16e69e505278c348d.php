<?php $__env->startSection('contenido'); ?>
<div class="container-fluid my-3">
    <div class="animated fadeIn">
        <div class="card">
            <div class="card-header">
                Mis cursos a cargo
                <div class="card-header-actions">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-bordered" id="dataTable">
                    <thead>
                        <tr class="table-info">
                            <th>Grado</th>
                            <th>Curso</th>
                            <th>Año</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mis_cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($mc->curs_grado <= 6): ?>
                                    <?php echo e($mc->curs_grado . '° de primaria'); ?>

                                <?php elseif($mc->curs_grado == 7): ?>
                                    <?php echo e('1° de secundaria'); ?>

                                <?php elseif($mc->curs_grado == 8): ?>
                                    <?php echo e('2° de secundaria'); ?>          
                                <?php elseif($mc->curs_grado == 9): ?>
                                    <?php echo e('3° de secundaria'); ?>  
                                <?php elseif($mc->curs_grado == 10): ?>
                                    <?php echo e('4° de secundaria'); ?>  
                                <?php elseif($mc->curs_grado == 11): ?>
                                    <?php echo e('5° de secundaria'); ?>  
                                <?php else: ?>
                                    <?php echo e('Egresado'); ?>  
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($mc->asig_nom); ?></td>
                            <td><?php echo e($mc->curs_año); ?></td>
                            <td>
                                <a class="btn btn-sm btn-light" href="<?php echo e(url('curso/'.$mc->curs_id)); ?>"><i class="fa fa-folder-open-o"></i></a>  
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JUANA ALARCO DE DAMMERT\new swcolegio\SWCOLEGIO\resources\views/docente/miscursos.blade.php ENDPATH**/ ?>