<div class="modal fade" id="modal-est-<?php echo e($alum->alum_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <form action="<?php echo e(url('alumno/'.$alum->alum_id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="modal-body">
                <?php if($alum->alum_est == 1): ?>
                    <h5>¿Deseas inactivar al alumno?</h5>
                <?php elseif($alum->alum_est == 0): ?>
                    <h5>¿Deseas activar al alumno?</h5>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <input type="submit" value="Enviar" class="btn btn-primary">
            </div>
        </form>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/alumno/estado.blade.php ENDPATH**/ ?>