<div class="modal fade" id="modal-info-<?php echo e($alum->alum_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detalle del alumno</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
            <div class="modal-body">
                <p>Datos del Estudiante:</p>
                <label class="form-control">DNI: <?php echo e($alum->alum_dni); ?></label>
                <label class="form-control">Apellidos: <?php echo e($alum->alum_ape); ?></label>
                <label class="form-control">Nombres: <?php echo e($alum->alum_nom); ?></label>
                <?php if($alum->alum_sexo == 1): ?>
                    <label for="" class="form-control">Sexo: Masculino</label>
                <?php elseif($alum->alum_sexo == 0): ?>
                    <label for="" class="form-control">Sexo: Femenino</label>
                <?php endif; ?>
                <label class="form-control">F. Nacimiento: <?php echo e(date("d/m/Y", strtotime($alum->alum_fnac))); ?></label>
                <label class="form-control">Grado: 

                <?php if($alum->alum_grad <= 6): ?>
                                    <?php echo e($alum->alum_grad . '° de primaria'); ?>

                                <?php elseif($alum->alum_grad == 7): ?>
                                    <?php echo e('1° de secundaria'); ?>

                                <?php elseif($alum->alum_grad == 8): ?>
                                    <?php echo e('2° de secundaria'); ?>          
                                <?php elseif($alum->alum_grad == 9): ?>
                                    <?php echo e('3° de secundaria'); ?>  
                                <?php elseif($alum->alum_grad == 10): ?>
                                    <?php echo e('4° de secundaria'); ?>  
                                <?php elseif($alum->alum_grad == 11): ?>
                                    <?php echo e('5° de secundaria'); ?>  
                                <?php else: ?>
                                    <?php echo e('Egresado'); ?>  
                                <?php endif; ?>
                </label>
                <?php if($alum->alum_est == 1): ?>
                    <label class="form-control">Estado: <span class="badge badge-success">Activo</span></label>
                <?php elseif($alum->alum_est == 0): ?>
                    <label class="form-control">Estado: <span class="badge badge-danger">Inactivo</span></label>
                <?php endif; ?>
                <p>Datos del Apoderado:</p>
                <label class="form-control">Apellidos: <?php echo e($alum->apod_ape); ?></label>
                <label class="form-control">Nombres: <?php echo e($alum->apod_nom); ?></label>
                <label class="form-control">E-mail: <?php echo e($alum->apod_email); ?></label>
                <label class="form-control">Teléfono: <?php echo e($alum->apod_tel); ?></label>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cerrar</button>
            </div>
    </div>
    <!-- /.modal-content-->
  </div>
  <!-- /.modal-dialog-->
</div><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/alumno/info.blade.php ENDPATH**/ ?>