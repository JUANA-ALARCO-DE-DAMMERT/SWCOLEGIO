<!DOCTYPE html>
<html>
<head>
	<title></title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
	<div class="header-wrapper">
      <div >
        <img src="<?php echo e(asset('img/logo-jad.jpeg')); ?>" width="40" height="40"> 
      </div>
      </div>

      <div>
      	<h5>
      	<center>
      		I.E.P. “JUANA ALARCO DE DAMMERT”
      	</center>
            </h5>
      	<p><center>
      			.- Un buen colegio al alcance de usted -. <br> SAN MIGUEL- R.D.Z. Nº 06390-1977
      	</center>
      </p>
      <h5>
      	<center>
      		INFORME ANUAL DE LOGROS DEL EDUCANDO <br> Valor Institucional: LA RESPONSABILIDAD <br> AÑO ESCOLAR - 2020 <br><a style="text-decoration: underline;"> 
                        NIVEL: <?php if($alumno->alum_grad == 1 || $alumno->alum_grad == 2 || $alumno->alum_grad == 3 || $alumno->alum_grad == 4 || $alumno->alum_grad == 5 || $alumno->alum_grad == 6): ?>
                                    PRIMARIA
                               <?php else: ?>
                                    SECUNDARIA
                               <?php endif; ?>
                  </a> 
      	</center>
      </h5>
      </div>

      <div>
      	Sr. Padre de Familia: <br> <b>ALUMNO(A): <?php echo e($alumno->alum_ape . ', ' . $alumno->alum_nom); ?> Gdo: 
                  <?php if($alumno->alum_grad == 7): ?>
                        1
                  <?php elseif($alumno->alum_grad == 8): ?>
                        2
                  <?php elseif($alumno->alum_grad == 9): ?>
                        3
                  <?php elseif($alumno->alum_grad == 10): ?>
                        4
                  <?php elseif($alumno->alum_grad == 11): ?>
                        5      
                  <?php else: ?>
                        <?php echo e($alumno->alum_grad); ?>

                  <?php endif; ?>

                                  ° Grado Nivel:
                  <?php if($alumno->alum_grad == 1 || $alumno->alum_grad == 2 || $alumno->alum_grad == 3 || $alumno->alum_grad == 4 || $alumno->alum_grad == 5 || $alumno->alum_grad == 6): ?>
                                    Primaria
                               <?php else: ?>
                                    Secundaria
                               <?php endif; ?> </b>
      </div>
      <table class="table table-hover table-bordered table-sm" id="dataTable" width="60%" cellspacing="0">
      	<thead>
	      	<tr>
	      		<th>  </th>
	      		<th><center>ÁREAS</center></th>
	      		<th><center>    I		<br>    B1		</center></th>
	      		<th><center>    II 	<br>    B1		</center></th>
	      		<th><center>    III	<br>    B1		</center></th>
	      		<th><center>    IV	<br>    B1		</center></th>
	      		<th><center>   Nota	<br>    Anu.	</center></th>
	      		<th><center>   Requ	<br>   Recu.	</center></th>
	      	</tr>
      	</thead>
      	<tbody>
				<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($c->asig_id); ?></td>
					<td><?php echo e($c->asig_nom); ?></td>
					<?php
						$query = DB::table('notas')
								->where('notas.not_idcurso','=',$c->curs_id)
								->where('notas.not_idalumno','=',$alumno->alum_id)
								->get();
					?>
					<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($q->not_promedio); ?></td>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<td></td>
					<td></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      	</tbody>
      </table>
      <p>Alumno(a) - Padres de Familia</p>
      <table class="table table-hover table-bordered table-sm" id="dataTable" width="60%" cellspacing="0">
            <thead>
                  <tr>
                        <th><center>a</center></th>
                        <th>Alno, Tardanzas.- Faltas - Suspensiones T=</th>
                        <th><center>F= </center></th>
                        <th><center>S= </center></th>
                  </tr>
            </thead>
            <tbody>
                  <tr>
                        <td><center>b</center></td>
                        <td>Padre de F.- Apoya plan lector.</td>
                        <td><center>Si</center></td>
                        <td><center>No</center></td>
                  </tr>
                  <tr>
                        <td><center>c</center></td>
                        <td>Padre de F.- Firma la agenda - Comunicados.</td>
                        <td><center>Si</center></td>
                        <td><center>No</center></td>
                  </tr>
                  <tr>
                        <td><center>d</center></td>
                        <td>Padre de F.- Responsable en sus compromisos con el colegio.</td>
                        <td><center>Si</center></td>
                        <td><center>No</center></td>
                  </tr>
                  <tr>
                        <td><center>e</center></td>
                        <td>Padre de F. - Asiste a la reuniones.</td>
                        <td><center>Si</center></td>
                        <td><center>No</center></td>
                  </tr>
                  <tr>
                        <td colspan="3" >Los Promedios = a 12 ó -s RR= REQUIEREN REFORZA.</td>
                  </tr>
            </tbody>
      </table>

                  <p>**Felicitamos a los Padres de Familia por su dedicacion en la Educacion a sus menores hijos.</p>
                  <p>*La mayor herencia que puede dejar un Padre a sus hijos, es el ejemplo de sus virtudes y de sus bellas acciones.</p>
                  <p><center>Sr. Padre de F. Si tiene alguna inquietud, no dude en acercarse a ala Direccion.</center></p><br>
      <table border="0">
            <tr>
                  <th><center>__________________________ <br> Prof.Tutor(a)</center></th>
                  <th><center>__________________________ <br> Padre de Familia</center></th>
                  <th><center>__________________________ <br> Vº.Bº Direccion</center></th>
            </tr>
      </table>




<?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/reportes/misnotas.blade.php ENDPATH**/ ?>