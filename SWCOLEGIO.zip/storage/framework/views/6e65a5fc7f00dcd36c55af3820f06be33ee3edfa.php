<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-md-6"></div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card my-3">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> Código del curso: <?php echo e($curso->curs_id); ?>

            </div>
            <div class="card-body">
                
                <a href="<?php echo e(url('asistencia/'.$curso->curs_id)); ?>" class="btn btn-light">Asistencias</a>
                <a href="<?php echo e(url($curso->curs_id.'/notas')); ?>" class="btn btn-light">Notas</a>
                <a href="<?php echo e(url($curso->curs_id.'/recursos')); ?>" class="btn btn-light">Recursos</a>
                <?php if(Auth::user()->hasRole('docen')): ?>
                    <a href="<?php echo e(url('newexamen',['idcurso'=>$curso->curs_id])); ?>" class="btn btn-light">Subir Exámen en línea</a>
                    <a href="<?php echo e(url('reportes/'.$curso->curs_id)); ?>" class="btn btn-light">Reportes</a>
                <?php endif; ?>
                <?php if(Auth::user()->hasRole('alum')): ?>
                    <a href="<?php echo e(url('exavirtual',['idcurso'=>$curso->curs_id])); ?>" class="btn btn-light">Ver exámen en línea</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/curso/show.blade.php ENDPATH**/ ?>