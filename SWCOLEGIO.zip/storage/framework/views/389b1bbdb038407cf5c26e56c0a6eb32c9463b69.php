<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <title>Alumnos</title>
      <meta name="viewport" content="">
      <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
	<div class="header-wrapper">
      <div >
        <img src="<?php echo e(asset('img/logo-jad.jpeg')); ?>" width="60" height="60">
      </div>
    </div>
    <div>
    	<H1 class="m-0 font-weight-bold text-primary"><center>ALUMNOS</center></H1>
    </div>
    <table class="table table-hover table-bordered table-sm" id="dataTable" width="80%" cellspacing="0"  >
                  <thead>
                        <tr>
 							<th>DNI</th>
							<th>Alumno</th>
							<th>Sexo</th>
							<th>F. Nacimiento</th>
							<th>Grado</th>	
							<th>Apoderado</th>
                        </tr>
                  </thead>
                  <tbody>
                  		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($a->alum_dni); ?></td>
							<td><?php echo e($a->alum_ape . ', ' . $a->alum_nom); ?></td>
							<?php if($a->alum_sexo == 1): ?>
                   			<td>Masculino</td>
              				 <?php elseif($a->alum_sexo == 0): ?>
                  		    <td>Femenino</td>
              				 <?php endif; ?>
                			<td><?php echo e(date("d/m/Y", strtotime($a->alum_fnac))); ?></td>
							
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
            </table>
            ----Datos adicionales---- <br>
            <p>1° de primaria: <?php echo e($n1alumnos); ?><br> 
		 	   2° de primaria: <?php echo e($n2alumnos); ?><br>
		 	   3° de primaria: <?php echo e($n3alumnos); ?><br>
		 	   4° de primaria: <?php echo e($n4alumnos); ?><br>

		 	</p>
			<p>Total: <?php echo e($totalalum); ?></p>
</body>
</html>

<!-- <p align="center"><strong>ALUMNOS</strong></p> <br>
<table border="1">
	<thead>
		<tr>
			<th>DNI</th>
			<th>Alumno</th>
			<th>Sexo</th>
			<th>F. Nacimiento</th>
			<th>Grado</th>	
			<th>Apoderado</th>			
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($a->alum_dni); ?></td>
			<td><?php echo e($a->alum_ape . ', ' . $a->alum_nom); ?></td>
			<?php if($a->alum_sexo == 1): ?>
                   <td>Masculino</td>
               <?php elseif($a->alum_sexo == 0): ?>
                   <td>Femenino</td>
               <?php endif; ?>
               <td><?php echo e(date("d/m/Y", strtotime($a->alum_fnac))); ?></td>
			<td>
				<?php if($a->alum_grad <= 6): ?>
                                    <?php echo e($a->alum_grad . '° de primaria'); ?>

                                <?php elseif($a->alum_grad == 7): ?>
                                    <?php echo e('1° de secundaria'); ?>

                                <?php elseif($a->alum_grad == 8): ?>
                                    <?php echo e('2° de secundaria'); ?>          
                                <?php elseif($a->alum_grad == 9): ?>
                                    <?php echo e('3° de secundaria'); ?>  
                                <?php elseif($a->alum_grad == 10): ?>
                                    <?php echo e('4° de secundaria'); ?>  
                                <?php elseif($a->alum_grad == 11): ?>
                                    <?php echo e('5° de secundaria'); ?>  
                                <?php else: ?>
                                    <?php echo e('Egresado'); ?>  
                                <?php endif; ?>
			</td>
			<td><?php echo e($a->apod_ape . ', ' . $a->apod_nom); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<p>1° de primaria: <?php echo e($n1alumnos); ?><br> 
 	   2° de primaria: <?php echo e($n2alumnos); ?><br>
 	   3° de primaria: <?php echo e($n3alumnos); ?><br>
 	   4° de primaria: <?php echo e($n4alumnos); ?><br>
 	   5° de primaria: <?php echo e($n5alumnos); ?><br>
 	   6° de primaria: <?php echo e($n6alumnos); ?><br>
 	   1° de secundaria: <?php echo e($n7alumnos); ?><br>
 	   2° de secundaria: <?php echo e($n8alumnos); ?><br>
 	   3° de secundaria: <?php echo e($n9alumnos); ?><br>
 	   4° de secundaria: <?php echo e($n10alumnos); ?><br>
 	   5° de secundaria: <?php echo e($n11alumnos); ?><br>
<p>Total: <?php echo e($totalalum); ?></p> --><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/pdf/alumnos.blade.php ENDPATH**/ ?>