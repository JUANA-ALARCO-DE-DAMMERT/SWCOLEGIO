<?php $__env->startSection('contenido'); ?>
<div class="container-fluid my-3">
    <div class="animated fadeIn">
        <div class="card">
            <div class="card-header">
                Mis pagos
            </div>
            <div class="card-body">
                <table class="row-border hover table-responsive" id="dataTable">
                    <thead>
                        <tr class="table-info">
                            <th>M. Anual</th>
                            <th>Dscto</th>
                            <th>M. Inicial</th>
                            <th>Marzo</th>
                            <th>Abril</th>
                            <th>Mayo</th>
                            <th>Junio</th>
                            <th>Julio</th>
                            <th>Agosto</th>
                            <th>Setiembre</th>
                            <th>Octubre</th>
                            <th>Noviembre</th>
                            <th>Diciembre</th>
                        </tr>
                    </thead>
                    <tbody> 
                            <?php $deuda = 0; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e('s/'.$d->montoanual); ?></td>
                    			<td><?php echo e('s/'.$d->descuento); ?></td>
                                <td><?php echo e('s/'.$d->inicial); ?></td>
                    			<td>
                                    <?php if($d->marzo >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->marzo.' P'); ?></span>
                                     <?php elseif($d->marzo < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->marzo.' D'); ?></span>
                                    <?php endif; ?>        
                                </td>
                    			<td>
                                    <?php if($d->abril >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->abril.' P'); ?></span>
                                     <?php elseif($d->abril < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->abril.' D'); ?></span>
                                    <?php endif; ?>                                     
                                </td>
                    			<td>
                                    <?php if($d->mayo >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->mayo.' P'); ?></span>
                                     <?php elseif($d->mayo < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->mayo.' D'); ?></span>
                                    <?php endif; ?> 
                                </td>
                    			<td>
                                    <?php if($d->junio >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->junio.' P'); ?></span>
                                     <?php elseif($d->junio < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->junio.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->julio >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->julio.' P'); ?></span>
                                     <?php elseif($d->julio < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->julio.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->agosto >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->agosto.' P'); ?></span>
                                     <?php elseif($d->agosto < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->agosto.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->setiembre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->setiembre.' P'); ?></span>
                                     <?php elseif($d->setiembre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->setiembre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->octubre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->octubre.' P'); ?></span>
                                     <?php elseif($d->octubre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->octubre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->noviembre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->noviembre.' P'); ?></span>
                                     <?php elseif($d->noviembre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->noviembre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->diciembre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->diciembre.' P'); ?></span>
                                     <?php elseif($d->diciembre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->diciembre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>

                                <?php 
                                    $deuda =  $d->marzo + 
                                              $d->abril +
                                              $d->mayo +
                                              $d->junio +
                                              $d->julio +
                                              $d->agosto +
                                              $d->setiembre +
                                              $d->octubre +
                                              $d->noviembre +
                                              $d->diciembre;   
                                ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <p> <strong>Deuda total: S/. <?php echo e($deuda); ?></strong></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/alumno/mispagos.blade.php ENDPATH**/ ?>