<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-md-6">
        <a href="<?php echo e(url('apoderado/create')); ?>" class="btn btn-primary">Registrar apoderado</a>
        <a href="<?php echo e(url('pdfapoderados')); ?>" class="btn btn-danger"><i class="fa fa-print"></i></a>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success" content="2">
        <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Apoderados</strong>
            </div>
            <div class="card-body">
                <table class="table table-responsive-sm table-hover table-sm" id="dataTable">
                    <thead>
                        <tr>
                            <th>DNI</th>
                            <th>Apellidos</th>
                            <th>Nombres</th>
                            <th>Sexo</th>
                            <th>Teléfono</th>
                            <th>E-mail</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $apoderados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($apod->apod_dni); ?></td>
                            <td><?php echo e($apod->apod_ape); ?></td>
                            <td><?php echo e($apod->apod_nom); ?></td>
                            <td>
                                <?php if($apod->apod_sexo == 1): ?>
                                    Masculino
                                <?php else: ?>
                                    Femenino
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($apod->apod_tel); ?></td>
                            <td><?php echo e($apod->apod_email); ?></td>
                            <td>   
                               <a href="<?php echo e(url('apoderado/'.$apod->apod_id.'/edit')); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JUANA ALARCO DE DAMMERT\new swcolegio\SWCOLEGIO\resources\views/apoderado/index.blade.php ENDPATH**/ ?>