
<!DOCTYPE html>
<html lang="en">
  <head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Sistema Web - Control Académico</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/logo-jad.jpeg')); ?>" >
    <!-- Icons-->
    <link href="<?php echo e(asset('plantilla/node_modules/@coreui/icons/css/coreui-icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plantilla/node_modules/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plantilla/node_modules/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plantilla/node_modules/simple-line-icons/css/simple-line-icons.css')); ?>" rel="stylesheet">
    <!-- Main styles for this application-->
    <link href="<?php echo e(asset('plantilla/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plantilla/vendors/pace-progress/css/pace.min.css')); ?>" rel="stylesheet">
    <!-- Global site tag (gtag.js) - Google Analytics-->
    <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
  </head>
  <body class="app flex-row align-items-center">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="card-group">
            <div class="card p-4">
              <div class="card-body">
                <div class="text-center">
                  <a class="navbar-brand" href="">
                    <img src="<?php echo e(asset('img/logo-jad.jpeg')); ?>" height="100px">
                  </a>
                  <h1>Login</h1>  
                  <p class="text-muted">Iniciar Sesion</p>
                </div>              
                <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                            <i class="icon-user"></i>
                            </span>
                        </div>
                        <input id="usuario" type="text" class="form-control <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="usuario" value="<?php echo e(old('usuario')); ?>" placeholder="Username" required autocomplete="usuario" maxlength="9" autofocus>                  
                        <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="input-group mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                            <i class="icon-lock"></i>
                            </span>
                        </div>
                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="current-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <input type="submit" value="Login" class="btn btn-primary px-4">
                        </div>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- CoreUI and necessary plugins-->
    <script src="<?php echo e(asset('plantilla/node_modules/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plantilla/node_modules/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plantilla/node_modules/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plantilla/node_modules/pace-progress/pace.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plantilla/node_modules/perfect-scrollbar/dist/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plantilla/node_modules/@coreui/coreui/dist/js/coreui.min.js')); ?>"></script>
  </body>
</html>

<?php /**PATH C:\xampp\htdocs\SWCOLEGIO\resources\views/auth/login.blade.php ENDPATH**/ ?>