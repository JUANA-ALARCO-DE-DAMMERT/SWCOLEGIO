<?php 
$trab_data = DB::table('trabajador')
                  ->join('role_user','role_user.user_id','trabajador.trab_dni')
                  ->join('roles','roles.id','role_user.role_id')
                  ->where('trabajador.trab_dni','=',Auth::user()->usuario)->first();
 ?>

<?php $__env->startSection('contenido'); ?>
<?php if(Auth::user()->hasAnyRole(['secre','admin'])): ?>
  <?php if($trab_data->trab_est == 1): ?>
<div class="row mt-4">
    <div class="col-md-6">
        <a href="<?php echo e(url('secretaria/create')); ?>" class="btn btn-primary">Registrar secretaria</a>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Secretarias</strong>
            </div>
            <div class="card-body">
                <table class="table table-responsive-sm table-hover table-sm" id="dataTable">
                    <thead>
                        <tr>
                            <th>DNI</th>
                            <th>Apellidos</th>
                            <th>Nombres</th>
                            <th>Sexo</th>
                            <th>Estado</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($trab->trab_dni); ?></td>
                            <td><?php echo e($trab->trab_ape); ?></td>
                            <td><?php echo e($trab->trab_nom); ?></td>
                            <td>
                                <?php if($trab->trab_sexo == 1): ?>
                                    Masculino
                                <?php else: ?>
                                    Femenino
                                <?php endif; ?>
                            </td>
                            <td>
                              <?php if($trab->trab_est == 1): ?>
                                <span class="badge badge-success">Activo</span>
                              <?php else: ?>
                              <span class="badge badge-danger">Inactivo</span>
                              <?php endif; ?>
                            </td>
                            <td>
                                <a data-toggle="modal" data-target="#modal-info-<?php echo e($trab->trab_id); ?>" class="btn btn-sm btn-info"><i class="fa fa-search"></i></a>      
                                <?php echo $__env->make('secretaria.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php if($trab->trab_est == 1): ?>
                                    <a data-toggle="modal" data-target="#modal-est-<?php echo e($trab->trab_id); ?>" title="Inactivar usuario" class="btn btn-sm btn-danger"><i class="fa fa-toggle-off"></i></a> 
                                <?php else: ?>
                                    <a data-toggle="modal" data-target="#modal-est-<?php echo e($trab->trab_id); ?>" title="Activar usuario" class="btn btn-sm btn-success"><i class="fa fa-toggle-on"></i></a> 
                                <?php endif; ?>     
                                <?php echo $__env->make('secretaria.estado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <a href="<?php echo e(url('secretaria/'.$trab->trab_id.'/edit')); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
<?php else: ?>
    <div class="d-sm-flex align-items-center justify-content-between my-4">
      <h1 class="h4 mb-0 text-gray-800">No tienes acceso </h1>
    </div>
  <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/secretaria/index.blade.php ENDPATH**/ ?>