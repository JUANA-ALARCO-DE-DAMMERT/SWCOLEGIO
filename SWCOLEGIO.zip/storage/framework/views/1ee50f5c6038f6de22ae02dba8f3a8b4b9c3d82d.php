<?php 
$trab_data = DB::table('trabajador')
                  ->join('role_user','role_user.user_id','trabajador.trab_dni')
                  ->join('roles','roles.id','role_user.role_id')
                  ->where('trabajador.trab_dni','=',Auth::user()->usuario)->first();
 ?>

<?php $__env->startSection('contenido'); ?>
<?php if(Auth::user()->hasAnyRole(['secre','admin'])): ?>
  <?php if($trab_data->trab_est == 1): ?>
<div class="row mt-4">
    <div class="col-md-6">
        <a href="<?php echo e(url('pago/create')); ?>" class="btn btn-primary">Agregar alumnos</a>
        <a href="<?php echo e(url('reportepagopdf/')); ?>" class="btn btn-danger"><i class="fa fa-file-pdf-o"></i></a>
        <a href="<?php echo e(url('reportepagoexcel/')); ?>" class="btn btn-success"><i class="fa fa-file-excel-o"></i></a>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Pagos - Juana Alarco de Dammert</strong>
            </div>
            <div class="card-body">
                <table class="tdisplay compact row-border hover table-responsive " id="dataTable">
                    <thead>
                        <tr>
                            <th>Año</th>
                            <th>DNI</th> 
                            <th>Alumno</th>
                            <th>M. Anual</th>
                            <th>Dscto</th>
                            <th>M. Inicial</th>
                            <th>Marzo</th>
                            <th>Abril</th>
                            <th>Mayo</th>
                            <th>Junio</th>
                            <th>Julio</th>
                            <th>Agosto</th>
                            <th>Setiembre</th>
                            <th>Octubre</th>
                            <th>Noviembre</th>
                            <th>Diciembre</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    		<tr>
                    			<td><?php echo e($d->año); ?></td>
                                <td><?php echo e($d->alum_dni); ?></td>
                    			<td><?php echo e($d->alum_ape . ', ' . $d->alum_nom); ?></td>
                    			<td><?php echo e('s/'.$d->montoanual); ?></td>
                    			<td><?php echo e('s/'.$d->descuento); ?></td>
                                <td><?php echo e('s/'.$d->inicial); ?></td>
                    			<td>
                                    <?php if($d->marzo >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->marzo.' P'); ?></span>
                                     <?php elseif($d->marzo < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->marzo.' D'); ?></span>
                                    <?php endif; ?>        
                                </td>
                    			<td>
                                    <?php if($d->abril >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->abril.' P'); ?></span>
                                     <?php elseif($d->abril < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->abril.' D'); ?></span>
                                    <?php endif; ?>                                     
                                </td>
                    			<td>
                                    <?php if($d->mayo >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->mayo.' P'); ?></span>
                                     <?php elseif($d->mayo < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->mayo.' D'); ?></span>
                                    <?php endif; ?> 
                                </td>
                    			<td>
                                    <?php if($d->junio >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->junio.' P'); ?></span>
                                     <?php elseif($d->junio < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->junio.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->julio >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->julio.' P'); ?></span>
                                     <?php elseif($d->julio < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->julio.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->agosto >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->agosto.' P'); ?></span>
                                     <?php elseif($d->agosto < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->agosto.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->setiembre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->setiembre.' P'); ?></span>
                                     <?php elseif($d->setiembre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->setiembre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->octubre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->octubre.' P'); ?></span>
                                     <?php elseif($d->octubre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->octubre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->noviembre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->noviembre.' P'); ?></span>
                                     <?php elseif($d->noviembre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->noviembre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                                    <?php if($d->diciembre >= 0): ?>
                                        <span class="badge badge-success"><?php echo e('s/'.$d->diciembre.' P'); ?></span>
                                     <?php elseif($d->diciembre < 0): ?>
                                        <span class="badge badge-danger"><?php echo e('s/'.$d->diciembre.' D'); ?></span>
                                    <?php endif; ?>          
                                </td>
                    			<td>
                    				<a href="<?php echo e(url('pago/'.$d->id.'/edit')); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>
                                    <a href="<?php echo e(url('pagos/'.$d->id)); ?>" class="btn btn-sm btn-secondary"><i class="fa fa-repeat"></i></a>
                    			</td>
                    		</tr>
                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
    <div class="d-sm-flex align-items-center justify-content-between my-4">
      <h1 class="h4 mb-0 text-gray-800">No tienes acceso </h1>
    </div>
  <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/pagos/index.blade.php ENDPATH**/ ?>