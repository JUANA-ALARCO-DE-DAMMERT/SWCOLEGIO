<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-md-6">
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card my-3">
            <div class="card-header">
                <div class="card-header-actions">
                    <a href="<?php echo e(url('home')); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <form action="<?php echo e(url('changepass')); ?>" method="POST" name="form" onsubmit="validar()">
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="row">                    
                    <div class="col-md-6">
                        <div class="form-group ">
                            <label>Nueva contraseña</label>
                            <input type="password" name="newpass" class="form-control" id="password">
                            <label>Confirmar contraseña</label>
                            <input type="password" name="confirmpass" class="form-control" id="cfmPassword">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <input type="submit" value="Cambiar Contraseña" class="btn btn-primary">  
                    </div>  
                </div>
                
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function validar(){
        var p1 = document.getElementById("password").value;
        var p2 = document.getElementById("cfmPassword").value;
        if (p1 == p2) {   
          document.form.submit();
          return true;
        } else {
          alert("Los passwords deben de coincidir");
          event.preventDefault();
          return false;
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/pwrd/mostrar.blade.php ENDPATH**/ ?>