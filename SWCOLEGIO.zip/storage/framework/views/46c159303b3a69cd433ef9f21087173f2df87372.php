<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Reset pagos</strong>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('pagosupdate')); ?>" method="POST" class="form-horizontal"> 
                <?php echo method_field('POST'); ?>
                <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                        <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                    	<input type="hidden" name="idalumno" value="<?php echo e($p->alum_id); ?>">
                        <label class="col-md-1 col-form-label">DNI</label>
                        <div class="col-md-2">
                            <input class="form-control" type="text" value="<?php echo e($p->alum_dni); ?>" readonly >
                        </div>
                        <label class="col-md-1 col-form-label">Apellidos</label>
                        <div class="col-md-4">
                            <input class="form-control" type="text" value="<?php echo e($p->alum_ape); ?>" readonly >
                        </div>
                        <label class="col-md-1 col-form-label">Nombres</label>
                        <div class="col-md-3">
                            <input class="form-control"  type="text" value="<?php echo e($p->alum_nom); ?>" readonly >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-1 col-form-label">M. Anual</label>
                        <div class="col-md-2">
                            <input class="form-control" type="text" name="montoanual" value="<?php echo e($p->montoanual); ?>">
                        </div>
                        <label class="col-md-1 col-form-label">Dscto</label>
                        <div class="col-md-2">
                            <input class="form-control" type="text" name="descuento" value="<?php echo e($p->descuento); ?>">
                        </div>
                        <label class="col-md-1 col-form-label">M. Inicial</label>
                        <div class="col-md-2">
                            <input class="form-control"  type="text" name="inicial" value="<?php echo e($p->inicial); ?>">
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" value="Modificar" class="btn btn-warning">
                        <a href="<?php echo e(url('pago')); ?>" class="btn btn-danger">Cancelar</a>
                    </div> 
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/pagos/reset.blade.php ENDPATH**/ ?>