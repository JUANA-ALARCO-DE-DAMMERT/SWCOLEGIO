<?php $__env->startSection('contenido'); ?>
<?php 
    $query = DB::table('notas')
                ->where('not_idcurso','=', $idcurso)
                ->where('not_bimestre','=', $nbim)
                ->get();
?>
<div class="row mt-4">
    <div class="col-md-6">
        <?php if(count($query)==0): ?>
            <a href="<?php echo e(url('registronotas/'.$idcurso.'/'.$nbim)); ?>" class="btn btn-primary">Registrar notas</a>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card my-3">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> Código del curso: <?php echo e($idcurso); ?> / <?php echo e($nbim); ?>° Bimestre 
                <div class="card-header-actions">
                    <a href="<?php echo e(url($idcurso.'/notas')); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-responsive" id="">
                    <thead>
                        <tr>
                            <th>Alumnos</th>
                            <th class="text-center">Promedio de separatas <br>( hojas de trabajo) <br> N1</th>
                            <th class="text-center">Promedio de <br>prácticas <br> N2</th>
                            <th class="text-center">Promedio de <br>participación <br> N3</th>
                            <th class="text-center">Promedio</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($a->alum_ape .', '.$a->alum_nom); ?></td>
                                <td class="text-center"><?php echo e($a->not_n1); ?></td>
                                <td class="text-center"><?php echo e($a->not_n2); ?></td>
                                <td class="text-center"><?php echo e($a->not_n3); ?></td>
                                <td class="text-center"><?php echo e($a->not_promedio); ?></td>
                                <td>
                                    <a href="<?php echo e(url('notas/'.$a->not_id.'/edit')); ?>" class="btn btn-sm btn-warning" ><i class="fa fa-pencil"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/notas/index.blade.php ENDPATH**/ ?>