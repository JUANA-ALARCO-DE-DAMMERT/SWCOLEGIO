<?php $__env->startSection('contenido'); ?>
<form action="<?php echo e(url('ac')); ?>" method="POST" >
<?php echo method_field('POST'); ?>
<?php echo e(csrf_field()); ?>

    <div class="row mt-4">
        <div class="col-md-6">
            <input type="submit" value="Matricular estudiantes" id="btn-only1click" class="btn btn-primary">
        </div>
        <div class="col-md-6">
            <input type="hidden" value="<?php echo e($curso->curs_id); ?>" name="curs_id">
        </div>
    </div>
    <div class="card my-3">
        <div class="card-body">
            <table class="table table-responsive-sm table-hover table-sm">
                <thead>
                    <tr>
                        <th><input type="checkbox" onclick="marcar(this);"></th>
                        <th>Alumno</th>
                        <th>Grado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" value="<?php echo e($a->alum_id); ?>" name="alumnos[]"></td>
                        <td><?php echo e($a->alum_ape . ', '. $a->alum_nom); ?></td>
                        <td>
                            <?php if($a->alum_grad <= 6): ?>
                                    <?php echo e($a->alum_grad . '° de primaria'); ?>

                                <?php elseif($a->alum_grad == 7): ?>
                                    <?php echo e('1° de secundaria'); ?>

                                <?php elseif($a->alum_grad == 8): ?>
                                    <?php echo e('2° de secundaria'); ?>          
                                <?php elseif($a->alum_grad == 9): ?>
                                    <?php echo e('3° de secundaria'); ?>  
                                <?php elseif($a->alum_grad == 10): ?>
                                    <?php echo e('4° de secundaria'); ?>  
                                <?php elseif($a->alum_grad == 11): ?>
                                    <?php echo e('5° de secundaria'); ?>  
                                <?php else: ?>
                                    <?php echo e('Egresado'); ?>  
                                <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	function marcar(source) 
	{
		checkboxes=document.getElementsByTagName('input'); //obtenemos todos los controles del tipo Input
		for(i=0;i<checkboxes.length;i++) //recoremos todos los controles
		{
			if(checkboxes[i].type == "checkbox") //solo si es un checkbox entramos
			{
				checkboxes[i].checked=source.checked; //si es un checkbox le damos el valor del checkbox que lo llamó (Marcar/Desmarcar Todos)
			}
		}
	}
</script>

<script type="text/javascript">
    // Variable global que nos dirá si hemos dado un click al botón
var clicando= false;

// Evento de click del primer botón
$("#btn-dobleclick").click(function() {
  // Mostramos el Alert
  alert( "Handler for dobleclick.click() called." );
});

// Evento del segundo boton
$("#btn-only1click").click(function() {
  // Si ha sido clicado
  if (clicando){
    // Mostramos que ya se ha clicado, y no puede clicarse de nuevo
    alert( "Que ya he realizado un click." );
  // Si no ha sido clicado
  } else {
    // Le decimos que ha sido clicado
    clicando= true;
    // Mostramos el mensaje de que ha sido clicado
    alert( "Alumnos Matriculados correctamente" );
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/curso/matricula.blade.php ENDPATH**/ ?>