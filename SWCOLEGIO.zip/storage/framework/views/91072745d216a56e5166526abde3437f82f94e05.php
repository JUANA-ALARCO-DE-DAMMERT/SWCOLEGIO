<div class="modal fade" id="modal-info-<?php echo e($doc->trab_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detalle del docente</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
            <div class="modal-body">
                <p>Datos personales:</p>
                <label class="form-control">DNI: <?php echo e($doc->trab_dni); ?></label>
                <label class="form-control">Apellidos: <?php echo e($doc->trab_ape); ?></label>
                <label class="form-control">Nombres: <?php echo e($doc->trab_nom); ?></label>
                <?php if($doc->trab_sexo == 1): ?>
                    <label for="" class="form-control">Sexo: Masculino</label>
                <?php elseif($doc->trab_sexo == 0): ?>
                    <label for="" class="form-control">Sexo: Femenino</label>
                <?php endif; ?>
                <label class="form-control">Fecha de Nacimiento: <?php echo e(date("d/m/Y", strtotime($doc->trab_fnac))); ?></label>
                <label class="form-control">E-mail: <?php echo e($doc->trab_email); ?></label>
                <label class="form-control">Teléfono: <?php echo e($doc->trab_tel); ?></label>
                <?php if($doc->trab_est == 1): ?>
                    <label class="form-control">Estado: <span class="badge badge-success">Activo</span></label>
                <?php elseif($doc->trab_est == 0): ?>
                    <label class="form-control">Estado: <span class="badge badge-danger">Inactivo</span></label>
                <?php endif; ?>
                <?php 
                $asignaturas = DB::table('asignatura_docente')
                                ->join('asignatura','asignatura.asig_id','asignatura_docente.asig_id')
                                ->where('trab_id','=',$doc->trab_id)
                                ->get();
                ?>
                <p>Asignaturas:</p>
                <?php $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="form-control"><?php echo e($a->asig_nom); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cerrar</button>
            </div>
    </div>
    <!-- /.modal-content-->
  </div>
  <!-- /.modal-dialog-->
</div><?php /**PATH C:\xampp\htdocs\SWCOLEGIO\resources\views/docente/info.blade.php ENDPATH**/ ?>