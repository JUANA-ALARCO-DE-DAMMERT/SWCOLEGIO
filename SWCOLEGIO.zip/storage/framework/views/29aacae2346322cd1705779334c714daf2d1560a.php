<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card my-3">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> Código del curso: <?php echo e($idcurso); ?> / Recursos
                <div class="card-header-actions">
                    <a href="<?php echo e(url('curso/'.$idcurso)); ?>" class="btn btn-block btn-outline-dark btn-sm"><i class="fa fa-mail-reply"></i></a>
                </div>
            </div>
            <div class="card-body">
                <a href="<?php echo e(url('recursos/'.$idcurso.'/1')); ?>" class="btn btn-light">1° Bimestre</a>
                <a href="<?php echo e(url('recursos/'.$idcurso.'/2')); ?>" class="btn btn-light">2° Bimestre</a>
                <a href="<?php echo e(url('recursos/'.$idcurso.'/3')); ?>" class="btn btn-light">3° Bimestre</a>
                <a href="<?php echo e(url('recursos/'.$idcurso.'/4')); ?>" class="btn btn-light">4° Bimestre</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/recursos/bimestres.blade.php ENDPATH**/ ?>