<form action="<?php echo e(url('datagrafico')); ?>" method="post">
	<?php echo method_field('POST'); ?>
	<?php echo e(csrf_field()); ?>

	<label>F. Inicio</label>
	<input type="date" name="finicio">
	<label>F. Fin</label>	
	<input type="date" name="ffin">
	<label>Asignatura</label>
	<select name="asig" >
		<option value="1">Matemáticas</option>
		<option value="2">Comunicación</option>
	</select>
	<input type="submit" value="Registrar">
</form><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/grafico/formasis.blade.php ENDPATH**/ ?>