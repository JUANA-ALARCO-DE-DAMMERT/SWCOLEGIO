<div class="modal fade" id="uploadFile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Subir recurso</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
        <form action="<?php echo e(url('upload')); ?>" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <?php echo e(csrf_field()); ?>

                <input type="file" name="rec_archivo" required>
                <input type="hidden" name="rec_curso" value="<?php echo e($idcurso); ?>">
                <input type="hidden" name="rec_bimestre" value="<?php echo e($nbim); ?>">
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                <button class="btn btn-primary" type="submit">Enviar</button>
            </div>
        </form>
    </div>
    <!-- /.modal-content-->
  </div>
  <!-- /.modal-dialog-->
</div><?php /**PATH C:\xampp\htdocs\JUANA ALARCO DE DAMMERT\new swcolegio\SWCOLEGIO\resources\views/recursos/modal-upload.blade.php ENDPATH**/ ?>