<?php $__env->startSection('contenido'); ?>
<?php 
    $alumnos = DB::table('alumno_curso')
                ->join('alumno','alumno.alum_id','alumno_curso.alumno_id')
                ->where('alumno_curso.curso_id','=',$idcurso)
                ->orderby('alumno.alum_ape','asc')
                ->get();
?>
<div class="row">
    <div class="col-md-12">
        <div class="card my-3">
            <form action="<?php echo e(url('asistencia')); ?>" method="POST" onsubmit="return checkSubmit();">
            <?php echo method_field('POST'); ?>
            <?php echo e(csrf_field()); ?>

            <div class="card-header">
                <div class="col-md-3">
                    <b>Elija La fecha de Asistencia :</b>
                    <input type="date" class="form-control" name="asis_fecha" min="2020-03-01" max="2020-12-31" required>
                    <input type="hidden" class="form-control" name="asis_idcurso" value="<?php echo e($idcurso); ?>">
                </div>
            </div>
            <div class="card-body">
                <table class="table table-responsive" id="">
                    <thead>
                        <tr>
                            <th class="">Alumnos</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($a->alum_ape.', '.$a->alum_nom); ?></td>
                                <input type="hidden" value="<?php echo e($a->alum_id); ?>" name="data[<?php echo e($a->alum_id); ?>][asis_idalumno]" class="form-control-plaintext">
                                <td>
                                    <select name="data[<?php echo e($a->alum_id); ?>][asis_est]" id="">
                                        <option value="0" selected>A</option>
                                        <option value="1">T</option>
                                        <option value="2">F</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <input type="submit" class="btn btn-primary" value="Registrar">
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
        enviando = false; //Obligaremos a entrar el if en el primer submit
    
    function checkSubmit() {
        if (!enviando) {
            enviando= true;
            return true;
        } else {
            //Si llega hasta aca significa que pulsaron 2 veces el boton submit
            alert("Solo se Hace un click en el boton Registrar"+" "+"Porfavor espere a que se suba la Asistencia que acaba de Registrar");
            return false;
        }
    }
</script>
<script type="text/javascript">

function desactivaBoton(id) {
   document.getElementById(id).disabled=true;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/asistencia/create.blade.php ENDPATH**/ ?>