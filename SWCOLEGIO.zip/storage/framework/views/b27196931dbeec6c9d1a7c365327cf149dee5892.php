<div class="modal fade" id="modal-info-<?php echo e($trab->trab_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detalle de trabajador</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
            <div class="modal-body">
                <p>Datos personales:</p>
                <label class="form-control">DNI: <?php echo e($trab->trab_dni); ?></label>
                <label class="form-control">Apellidos: <?php echo e($trab->trab_ape); ?></label>
                <label class="form-control">Nombres: <?php echo e($trab->trab_nom); ?></label>
                <?php if($trab->trab_sexo == 1): ?>
                    <label for="" class="form-control">Sexo: Masculino</label>
                <?php elseif($trab->trab_sexo == 0): ?>
                    <label for="" class="form-control">Sexo: Femenino</label>
                <?php endif; ?>
                <label class="form-control">Fecha de Nacimiento: <?php echo e(date("d/m/Y", strtotime($trab->trab_fnac))); ?></label>
                <?php if($trab->trab_est == 1): ?>
                    <label class="form-control">Estado: <span class="badge badge-success">Activo</span></label>
                <?php elseif($trab->trab_est == 0): ?>
                    <label class="form-control">Estado: <span class="badge badge-danger">Inactivo</span></label>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cerrar</button>
            </div>
    </div>
    <!-- /.modal-content-->
  </div>
  <!-- /.modal-dialog-->
</div><?php /**PATH C:\xampp\htdocs\JUANA ALARCO DE DAMMERT\new swcolegio\SWCOLEGIO\resources\views/secretaria/info.blade.php ENDPATH**/ ?>