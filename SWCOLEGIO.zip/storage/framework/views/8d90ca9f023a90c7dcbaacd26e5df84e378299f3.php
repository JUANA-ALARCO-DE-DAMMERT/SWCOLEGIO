<?php $__env->startSection('contenido'); ?>
<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Modificar administrador</strong>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('administrador/'.$trab->trab_id)); ?>" method="POST" class="form-horizontal"> 
                <?php echo method_field('PATCH'); ?>
                <?php echo e(csrf_field()); ?>

                    <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <p>Corregir los siguientes campos:</p>
                        <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <div class="form-group row">
                        <label class="col-md-1 col-form-label">DNI</label>
                        <div class="col-md-2">
                            <input class="form-control" id="" type="text" name="trab_dni" onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo e($trab->trab_dni); ?>" required readonly>
                        </div>
                        <label class="col-md-1 col-form-label">Apellidos</label>
                        <div class="col-md-4">
                            <input class="form-control" id="" type="text" name="trab_ape" onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo e($trab->trab_ape); ?>" required readonly>
                        </div>
                        <label class="col-md-1 col-form-label">Nombres</label>
                        <div class="col-md-3">
                            <input class="form-control" id="" type="text" name="trab_nom" onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo e($trab->trab_nom); ?>" required readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-1 col-form-label">Sexo</label>
                            <div class="col-md-2" >
                                <select class="form-control" id="" name="trab_sexo" required readonly >
                                    <option value="" hidden>-- Seleccione --</option>
                                        <?php if($trab->trab_sexo == 1): ?>
                                    <option selected="" value="1" >Masculino</option>
                                        <?php else: ?>
                                    <option selected="" value="0">Femenino</option>
                                        <?php endif; ?>
                                </select >                       
                            </div>
                        <label class="col-md-1 col-form-label">E-mail</label>
                        <div class="col-md-3">
                            <input class="form-control" id="" type="email" name="trab_email" value="<?php echo e($trab->trab_email); ?>" placeholder="">
                        </div>
                        <label class="col-md-1 col-form-label">Teléfono</label>
                        <div class="col-md-2">
                            <input class="form-control" id="" type="text" name="trab_tel" value="<?php echo e($trab->trab_tel); ?>" placeholder="">
                        </div>
                    </div>  
                    <div class="form-actions">
                        <input type="submit" value="Editar" class="btn btn-warning">
                        <a href="<?php echo e(url('administrador')); ?>" class="btn btn-danger">Cancelar</a>
                    </div> 
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TESISORIGINAL\SWCOLEGIO\resources\views/administrador/edit.blade.php ENDPATH**/ ?>